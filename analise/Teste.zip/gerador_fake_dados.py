import pandas as pd
import numpy as np

print("Gerando dados fakes para o monitoramento do motor...")

# Parâmetros da simulação
NUM_PONTOS = 100000
PERIODO_NORMAL = int(NUM_PONTOS * 0.6)
PERIODO_AQUECIMENTO = int(NUM_PONTOS * 0.3)
PERIODO_FALHA = NUM_PONTOS - PERIODO_NORMAL - PERIODO_AQUECIMENTO

# --- Geração de dados de TEMPERATURA com padrões ---
temp_normal = np.random.normal(loc=45, scale=2, size=PERIODO_NORMAL)
temp_aquecimento = np.linspace(start=temp_normal[-1], stop=85, num=PERIODO_AQUECIMENTO) + np.random.normal(scale=1.5, size=PERIODO_AQUECIMENTO)
temp_falha = np.random.normal(loc=110, scale=5, size=PERIODO_FALHA)
temperatura_C = np.concatenate([temp_normal, temp_aquecimento, temp_falha])

# --- Geração de dados de VIBRAÇÃO (acel_x) com padrões ---
vibracao_normal = np.random.normal(loc=0.5, scale=0.2, size=PERIODO_NORMAL + PERIODO_AQUECIMENTO)
vibracao_falha = np.random.normal(loc=5, scale=1.5, size=PERIODO_FALHA)
acel_x = np.concatenate([vibracao_normal, vibracao_falha])

# --- Geração de outros dados com variações simples ---
timestamp_ms = np.arange(0, NUM_PONTOS * 2000, 2000)
umidade_pct = np.random.normal(loc=30, scale=5, size=NUM_PONTOS)
acel_y = np.random.normal(loc=0, scale=0.2, size=NUM_PONTOS)
acel_z = np.random.normal(loc=9.8, scale=0.1, size=NUM_PONTOS)

# --- Montagem do DataFrame ---
df_fake = pd.DataFrame({
    'timestamp_ms': timestamp_ms,
    'temperatura_C': temperatura_C.round(2),
    'umidade_pct': umidade_pct.round(2),
    'acel_x': acel_x.round(4),
    'acel_y': acel_y.round(4),
    'acel_z': acel_z.round(4)
})

# Salvar no arquivo CSV
df_fake.to_csv('dados_fake_motor.csv', index=False)

print("--> Arquivo 'dados_fake_motor.csv' criado com sucesso!")