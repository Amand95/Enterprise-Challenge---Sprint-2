import pandas as pd
import matplotlib.pyplot as plt
import os

# --- Configuração ---
NOME_ARQUIVO_CSV = 'dados_motor.csv'
# A palavra-chave que o script vai procurar para saber onde os dados começam
PALAVRA_CHAVE_INICIO = 'timestamp_ms' 

# --- Início do Script ---
try:
    # --- NOVA LÓGICA INTELIGENTE PARA ACHAR O CABEÇALHO ---
    print(f"Procurando o início dos dados ('{PALAVRA_CHAVE_INICIO}') no arquivo '{NOME_ARQUIVO_CSV}'...")
    
    linhas_para_pular = 0
    with open(NOME_ARQUIVO_CSV, 'r', encoding='utf-8') as f:
        for linha in f:
            if PALAVRA_CHAVE_INICIO in linha:
                break
            linhas_para_pular += 1
    
    print(f"--> Cabeçalho encontrado! Ignorando as primeiras {linhas_para_pular} linhas de boot log.")

    # Agora, lemos o CSV de forma inteligente, pulando o lixo do início
    df = pd.read_csv(NOME_ARQUIVO_CSV, skiprows=linhas_para_pular)
    
    # --- O RESTO DO CÓDIGO CONTINUA IGUAL ---
    print("\nDados carregados com sucesso!")
    print("Amostra dos dados:")
    print(df.head())
    
    print("\nInformações sobre as colunas:")
    df.info()

    # --- Criação dos Gráficos ---

    # Gráfico 1: Temperatura ao longo do tempo
    plt.figure(figsize=(14, 7))
    plt.plot(df['timestamp_ms'], df['temperatura_C'], label='Temperatura (°C)', color='red', marker='o', linestyle='-', markersize=4)
    plt.title('Monitoramento de Temperatura do Motor ao Longo do Tempo')
    plt.xlabel('Tempo (milissegundos)')
    plt.ylabel('Temperatura (°C)')
    plt.grid(True)
    plt.legend()
    plt.savefig('grafico_temperatura.png') # Salva o gráfico
    print("\n--> Gráfico 'grafico_temperatura.png' salvo com sucesso!")
    plt.show()

    # Gráfico 2: Vibração (usando o eixo X da aceleração como exemplo)
    plt.figure(figsize=(14, 7))
    plt.plot(df['timestamp_ms'], df['acel_x'], label='Vibração (Eixo X)', color='blue', marker='.', linestyle='-')
    plt.title('Monitoramento de Vibração do Motor (Eixo X) ao Longo do Tempo')
    plt.xlabel('Tempo (milissegundos)')
    plt.ylabel('Aceleração (m/s^2)')
    plt.grid(True)
    plt.legend()
    plt.savefig('grafico_vibracao.png') # Salva o gráfico
    print("--> Gráfico 'grafico_vibracao.png' salvo com sucesso!")
    plt.show()

except FileNotFoundError:
    print(f"ERRO: Arquivo '{NOME_ARQUIVO_CSV}' não encontrado.")
    print("Por favor, execute a coleta de dados com o 'wokwi-cli' primeiro.")
except Exception as e:
    print(f"Ocorreu um erro inesperado: {e}")