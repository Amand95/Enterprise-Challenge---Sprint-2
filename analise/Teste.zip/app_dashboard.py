import streamlit as st
import pandas as pd
import os

# --- Configuração da Página ---
st.set_page_config(page_title="Dashboard de Monitoramento", layout="wide")
st.title("📈 Dashboard de Monitoramento de Motor Industrial")
st.markdown("Desafio em parceria com a **Hermes Reply**")

# --- Barra Lateral para Seleção de Dados ---
st.sidebar.header("Configurações")
fonte_dados = st.sidebar.radio(
    "Escolha a fonte dos dados:",
    ("Dados Reais (Simulação Wokwi)", "Dados Fakes (Gerados)")
)

# --- Carregamento dos Dados ---
nome_arquivo = ''
if fonte_dados == "Dados Reais (Simulação Wokwi)":
    nome_arquivo = 'dados_motor.csv'
else:
    nome_arquivo = 'dados_fake_motor.csv'

st.header(f"Visualizando: {fonte_dados}")

if os.path.exists(nome_arquivo):
    try:
        # Lógica inteligente para pular o boot log
        linhas_para_pular = 0
        with open(nome_arquivo, 'r', encoding='utf-8') as f:
            for linha in f:
                if 'timestamp_ms' in linha:
                    break
                linhas_para_pular += 1
        
        df = pd.read_csv(nome_arquivo, skiprows=linhas_para_pular)

        # --- Exibição dos Dados ---
        st.subheader("Amostra dos Dados")
        st.dataframe(df.head())

        st.subheader("Análise Gráfica")
        
        col1, col2 = st.columns(2)

        with col1:
            st.markdown("#### Temperatura (°C) ao longo do tempo")
            st.line_chart(df, x='timestamp_ms', y='temperatura_C', color='#FF4B4B')

        with col2:
            st.markdown("#### Umidade (%) ao longo do tempo")
            st.line_chart(df, x='timestamp_ms', y='umidade_pct', color='#0068C9')

        st.markdown("#### Vibração (Aceleração nos 3 eixos)")
        st.line_chart(df, x='timestamp_ms', y=['acel_x', 'acel_y', 'acel_z'])

    except Exception as e:
        st.error(f"Ocorreu um erro ao processar o arquivo '{nome_arquivo}': {e}")
else:
    st.warning(f"Arquivo '{nome_arquivo}' não encontrado! Por favor, gere os dados primeiro.")
    if fonte_dados == "Dados Reais (Simulação Wokwi)":
        st.info("Execute a simulação no Wokwi e salve os dados.")
    else:
        st.info("Execute o script 'gerador_fake_dados.py' para criar os dados de teste.")