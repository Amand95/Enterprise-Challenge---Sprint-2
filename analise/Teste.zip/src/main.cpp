#include <Arduino.h>
#include "Wire.h"
#include "DHT.h"
#include "Adafruit_MPU6050.h"
#include "Adafruit_Sensor.h"

// --- Configuração dos Pinos e Sensores ---
#define DHT_PIN 15      // Pino de dados do DHT22 conectado ao GPIO 15
#define DHT_TYPE DHT22  // Define o tipo do sensor como DHT22

// Inicializa os objetos dos sensores
DHT dht(DHT_PIN, DHT_TYPE);
Adafruit_MPU6050 mpu;

void setup() {
  // Inicia a comunicação serial com a velocidade definida no platformio.ini
  Serial.begin(115200);
  Serial.println("\n--- Sistema de Monitoramento Hermes Reply ---");
  Serial.println("--- INICIADO ---");

  // Inicia o sensor DHT22
  dht.begin();

  // Inicia o sensor MPU6050
  if (!mpu.begin()) {
    Serial.println("AVISO: Falha ao encontrar o MPU6050. Verifique o circuito em diagram.json.");
    // A simulação não será travada, mas os dados do MPU6050 podem não ser válidos.
  }
  
  Serial.println("Sensores prontos para a coleta de dados.");
  delay(2000); // Pausa para garantir que tudo esteja estável

  // Imprime o cabeçalho do CSV para facilitar a análise dos dados
  Serial.println("timestamp_ms,temperatura_C,umidade_pct,acel_x,acel_y,acel_z");
}

void loop() {
  // Gera um timestamp em milissegundos desde que o ESP32 ligou
  unsigned long timestamp = millis();

  // Lê os dados de temperatura e umidade do sensor DHT22
  float temperatura = dht.readTemperature();
  float umidade = dht.readHumidity();

  // Objeto para armazenar os eventos (leituras) do acelerômetro
  sensors_event_t a, g, temp;
  mpu.getEvent(&a, &g, &temp);

  // Verificação para garantir que a leitura do DHT não falhou (retornando "NaN" - Not a Number)
  if (isnan(temperatura) || isnan(umidade)) {
    Serial.println("Falha na leitura do sensor DHT!");
  } else {
    // Imprime todos os dados formatados como uma linha de CSV no Monitor Serial
    Serial.print(timestamp);
    Serial.print(",");
    Serial.print(temperatura, 2); // Imprime com 2 casas decimais
    Serial.print(",");
    Serial.print(umidade, 2);
    Serial.print(",");
    Serial.print(a.acceleration.x, 4); // Imprime com 4 casas decimais para mais precisão
    Serial.print(",");
    Serial.print(a.acceleration.y, 4);
    Serial.print(",");
    Serial.println(a.acceleration.z, 4);
  }
  
  // Espera 2 segundos (2000 ms) para a próxima rodada de leituras
  delay(2000);
}